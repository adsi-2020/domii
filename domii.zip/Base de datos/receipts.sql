CREATE TABLE receipts (
	id_receipt INT(15) AUTO_INCREMENT NOT NULL,
	id_order INT(15) NOT NULL,
	date_receipt TIMESTAMP NOT NULL,

	CONSTRAINT receipts_id_receipt_pk PRIMARY KEY (id_receipt),
	CONSTRAINT receipts_id_order_fk FOREIGN KEY (id_order)
		REFERENCES orders (id_order)
);