CREATE TABLE enterprises (
	id_enterprise INT(15) AUTO_INCREMENT NOT NULL,
	name_enterprise VARCHAR(50) NOT NULL,
	description_enterprise VARCHAR(255) NOT NULL,
	owner_enterprise VARCHAR(50) NOT NULL,
	address_enterprise VARCHAR(50) UNIQUE NOT NULL,
	email_enterprise VARCHAR(50) UNIQUE NOT NULL,
	phone_enterprise VARCHAR(50) NOT NULL, 
	img_enterprise VARCHAR(255) NOT NULL,
	id_user INT(15),
	active BOOLEAN NOT NULL,

	CONSTRAINT enterprises_id_enterprise_pk PRIMARY KEY (id_enterprise),
	CONSTRAINT enterprises_id_user_fk FOREIGN KEY (id_user)
		REFERENCES users (id_user)
);