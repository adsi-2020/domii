CREATE TABLE roles (
	id_rol INT(15) AUTO_INCREMENT NOT NULL,
	name_rol VARCHAR(50) NOT NULL,

	CONSTRAINT roles_id_rol_pk PRIMARY KEY (id_rol)
);

INSERT INTO roles (name_rol)
VALUES ("ADMINISTRADOR"),
	   ("CLIENTE"),
	   ("EMPRESARIO");
