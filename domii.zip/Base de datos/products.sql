CREATE TABLE products (
	id_product INT(15) AUTO_INCREMENT NOT NULL,
	name_product VARCHAR(50) NOT NULL,
	description_product VARCHAR(100) NOT NULL,
	price_product INT(50) NOT NULL,
	img_product VARCHAR(255) NOT NULL,
	id_enterprise INT(15) NOT NULL,

	CONSTRAINT products_id_product_pk PRIMARY KEY (id_product),
	CONSTRAINT products_id_enterprise_fk FOREIGN KEY (id_enterprise)
		REFERENCES enterprises (id_enterprise)
);