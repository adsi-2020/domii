CREATE TABLE orders (
	id_order INT(15) AUTO_INCREMENT NOT NULL,
	id_user INT(15) NOT NULL,
	id_product INT(15) NOT NULL,
	quantity_product VARCHAR(50) NOT NULL,
	price_product INT(15) NOT NULL,
	total_order INT(100) NOT NULL,
	phone_order VARCHAR(15) NOT NULL,
	address_order VARCHAR(100) NOT NULL,
	id_enterprise INT(15) NOT NULL,
	date_order TIMESTAMP NOT NULL,

	CONSTRAINT orders_id_order_pk PRIMARY KEY (id_order),

	CONSTRAINT orders_id_user_fk FOREIGN KEY (id_user)
		REFERENCES users (id_user),
	CONSTRAINT orders_id_product_fk FOREIGN KEY (id_product)
		REFERENCES products (id_product),
	CONSTRAINT orders_id_enterprise_fk FOREIGN KEY (id_enterprise)
		REFERENCES enterprises (id_enterprise)
);