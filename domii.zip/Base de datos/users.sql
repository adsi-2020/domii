CREATE TABLE users (
	id_user INT(15) AUTO_INCREMENT NOT NULL,
	name_user VARCHAR(50) NOT NULL,
	email_user VARCHAR(100) UNIQUE NOT NULL,
	id_google_user VARCHAR(50) NOT NULL,
	id_rol INT(15) DEFAULT 2,
	id_enterprise INT(15) DEFAULT NULL,
	active BOOLEAN DEFAULT 1,

	CONSTRAINT users_id_user_pk PRIMARY KEY (id_user),
	CONSTRAINT users_id_rol_fk FOREIGN KEY (id_rol)
		REFERENCES roles (id_rol),
	CONSTRAINT user_id_enterprise_fk FOREIGN KEY (id_enterprise)
		REFERENCES enterprises (id_enterprise)
); 

INSERT INTO users
(name_user, email_user, id_google_user, id_rol)
VALUES
('ADMIN', 'proyectosena46@gmail.com','114761702243340206990', 1);