<?php 

require_once("../model/products.php");

if ($_POST)
{
	$product = new Product();

	$id = $_POST['id'];

	if($product->delete($id))
	{
		header('localtion: ../../empresas/views/index.php');  
	}

	else {

		header('Location: ../../home/index.php'); 
	}

}
else {

	header('Location: ../../home/index.php');  
}

?> 
