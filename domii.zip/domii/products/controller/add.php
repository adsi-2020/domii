<?php 

	session_start();
	require_once("../model/products.php");
	require_once("../../empresas/model/enterprises.php");

	if ($_POST)
	{
		$product = new Product();

		$id_enterprise = $_POST['id'];
		$name = $_POST['name'];
		$description = $_POST['description']; 
		$price = $_POST['price'];
		$name_img = $_FILES['image']['name'];
		$typeImg = $_FILES['image']['type'];
		$sizeImg = $_FILES['image']['size'];

		if ($sizeImg<=5000000)
		{
			if ($typeImg== "image/jpeg" || $typeImg=="image/jpg" || $typeImg=="image/png" || $typeImg=="image/gif")
			{
				//ruta de la carpeta de destino en el servidor
				$target = $_SERVER['DOCUMENT_ROOT'] . '/domii/public/img/'; 

				//movemos la imagen del directorio temporal a el directorio de destino original 
				move_uploaded_file($_FILES['image']['tmp_name'], $target . $name_img);
			}

			else
			{
				echo "Solo se pueden subir imagenes con extenciones tipo: jpeg/jpg/png/gif";
			}
		}

		else
		{
			echo "El archivo supera el limite del tamaño";
		}

		if($product->add($id_enterprise, $name, $description, $price, $name_img))
		{
			header("location: ../../empresas/views/index.php?id={$id_enterprise}");
		}

		else {

			header('location: ../../home/index.php'); 
		}

	}

	else
	{
		header('location: ../../home/index.php');  
	}
?>