<?php 

require_once("../model/products.php");

if ($_POST)
{
	$product = new Product();

	$id_product = $_POST['id_product'];
	$id_enterprise =$_POST['id_enterprise'];
	$name = $_POST['name'];
	$description = $_POST['description']; 
	$price = $_POST['price'];
	$image=$_FILES['image']['name'];
	$typeImg=$_FILES['image']['type'];
	$sizeImg=$_FILES['image']['size'];

	if ($sizeImg<=5000000)
	{
		if ($typeImg== "image/jpeg" || $typeImg=="image/jpg" || $typeImg=="image/png" || $typeImg=="image/gif")
		{

			//ruta de la carpeta de destino en el servidor
			$target = $_SERVER['DOCUMENT_ROOT'] . '/domii/public/img/';

			//movemos la imagen del directorio temporal a el directorio de destino original 
			move_uploaded_file($_FILES['image']['tmp_name'], $target . $image);
		}

		else 
		{
			echo "Solo se pueden subir imagenes con extenciones tipo: jpeg/jpg/png/gif";
		}
	} 

	else
	{
		echo "El archivo supera el limite del tamaño";
	}


	if($product->update($id_product, $name, $description, $price, $image))
	{
		header("Location: ../../empresas/views/index.php?id={$id_enterprise}");
	}

	else {

		header("Location: ../../empresas/views/index.php?id={$id_enterprise}");
	}

}
else
{
	header('Location: ../../home/index.php');
}

?>