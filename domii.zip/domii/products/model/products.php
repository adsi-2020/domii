<?php

require_once("C:/xampp/htdocs/domii/app/Connection.php"); 

class Product extends Connection
{ 
	public function __construct()
	{
		$this->db = parent::__construct();
	} 

	public function add($id_enterprise, $name, $description, $price, $name_img)
	{
		$statement = $this->db->prepare("INSERT INTO products (name_product, description_product, price_product, img_product, id_enterprise) VALUES (:name, :description, :price, :name_img, :id_enterprise)");

		$statement->bindParam(":id_enterprise", $id_enterprise);
		$statement->bindParam(":name", $name);
		$statement->bindParam(":description", $description);
		$statement->bindParam(":price", $price);
		$statement->bindParam(":name_img", $name_img);

		return ($statement->execute()) ? true : false;
	}

	public function getProduct()
	{

		$statement = $this->db->prepare("SELECT * FROM products");
		$statement->execute();

		while ($dataProduct = $statement->fetch())
		{
			$rows[] = $dataProduct;
		}

		return $rows;

	}

	public function getById($id_product)
	{
		$statement = $this->db->prepare("SELECT * FROM products WHERE id_product = :id_product");

		$statement->bindParam(":id_product", $id_product);
		$statement->execute(); 

		while ($dataProduct = $statement->fetch())
		{
			$rows = $dataProduct;
		}

		return $rows;
	}

	public function update($id_product, $name, $description, $price, $image)  
	{
		$statement = $this->db->prepare("UPDATE products SET id_product = :id_product, name_product = :name, description_product = :description, price_product = :price, img_product = :image WHERE id_product = :id_product");

		$statement->bindParam(":id_product", $id_product); 
		$statement->bindParam(":name", $name);
		$statement->bindParam(":description", $description);
		$statement->bindParam(":price", $price);
		$statement->bindParam(":image", $image);
		 
		if ($statement->execute())  
		{ 
			header('Location: ../../empresas/views/index.php');
		}

		else
		{ 
			header('Location: ../views/edit.php');  
		}
	}

	public function delete($id) 
	{
		$statement = $this->db->prepare("DELETE FROM products WHERE id_product = :id");
		$statement->bindParam(":id", $id); 



		if ($statement->execute()) 
		{
			header('Location: ../views/index.php');   
		}

		else
		{
			header('Location: ../views/delete.php');
		}
	}

	public function getProducts($id) 
	{
		$sql = "SELECT * FROM products WHERE id_product = :id";
		$stmt = $this->db->prepare($sql);
		$stmt->bindParam(":id", $id);
		$stmt->execute();

		while ($result = $stmt->fetch())
		{
			$listProducts = $result;
		}

		return $listProducts;
	}

	public function getImg($id_enterprise)
	{
		$sql = "SELECT img_product FROM products WHERE id_enterprise = :id_enterprise";
		$stmt = $this->db->prepare($sql);
		$stmt->bindParam(":id_enterprise", $id_enterprise);
		$stmt->execute();

		$img = $stmt->fetch();

		return (isset($img)) ? $img[0] : null;
	}
}
?> 