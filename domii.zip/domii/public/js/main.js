(function() {
	const btnMainMenu = document.getElementById("btnMainMenu")
	const mainMenu = document.getElementById("mainMenu")
	if (btnMainMenu)
	{
		btnMainMenu.addEventListener("click", () => {
			mainMenu.classList.toggle("show")
		})
	}

	const btnSubMenu = mainMenu.querySelector(".link-my-enterprise")
	if (btnSubMenu)
	{	
		btnSubMenu.addEventListener("click", e => {
			e.preventDefault()
			const subMenu = mainMenu.querySelector(".main-menu--submenu")
			subMenu.classList.toggle("show-submenu")
		})
	}

	const formsAdmin = Array.from(document.querySelectorAll(".formAdmin"))
	formsAdmin.map(el => {
		selects = Array.from(el.querySelectorAll("select"))
		selects.map(el => {
			el.addEventListener("change", e => {
				el.parentNode.submit()
			})
		})
	})

	const formsBuy = Array.from(document.querySelectorAll(".formBuy"))
	if (formsBuy)
	{
		const loaderModal = document.getElementById("loaderModal")
		formsBuy.map(el => {
			el.addEventListener("submit", () => {
				loaderModal.classList.remove("is-hidden")
			})
		})
	}

	const tabs = Array.from(document.querySelectorAll('.tabs__item'))
	const panels = Array.from(document.querySelectorAll('.panels__item'))
	document.getElementById('tabs').addEventListener('click', e => {
		if (e.target.classList.contains('tabs__item'))
		{		
			const i = tabs.indexOf(e.target)
			tabs.map(tab => tab.classList.remove('active'))
			tabs[i].classList.add('active')
			panels.map(panel => panel.classList.remove('active'))
			panels[i].classList.add('active')
		}
	})

	$(".iconPoints").on("click", function() {
		$(this).next().slideToggle()
	})
	
	$(".btn-buy").on("click", function() {
		$(this).next().slideToggle()
	})

})()