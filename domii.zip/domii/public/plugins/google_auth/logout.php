<?php

	session_start();

	include('config.php');

	$google_client->revokeToken();

	$_SESSION['id_user'] 	= null;
	$_SESSION['email_user'] = null;
	$_SESSION['id_rol'] 	= null;
	session_destroy();

	header("Status: 301 Moved Permanently");
	header('location: ../../../index.php');
	exit();
?>