# Login-con-la-API-de-google
Inicio de sesión con la API de Google usando PHP

Archivos necesarios:
- config.php
- index.php
- logout.php
