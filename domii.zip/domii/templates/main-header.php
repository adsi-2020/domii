<header class="main-header">
	<div class="group">
		<div class="box">
			<?php if($user->isLoged()): ?>
				<i class="icon-bars" id="btnMainMenu"></i>
			<?php endif ?>
		</div>
		<div class="box">
			<div class="logo">
				<span>domii</span>
			</div>
		</div>
		<div class="box">
			<?php if ($user->isLoged() && !empty($user->getImg())): ?>
			<img src="<?php echo $user->getImg() ?>" alt="imagen de usuario" class="img-user">
		<?php endif ?>
		</div>
	</div>
</header>