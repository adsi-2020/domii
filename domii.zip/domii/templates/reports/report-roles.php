<?php
require_once("../../administrators/model/administrators.php");
$administrator = new Administrator();
$listRoles = $administrator->getRoles();
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reporte de roles</title>
	<style>

		body {
			font-family: sans-serif;
			color: #4C4C4C;
		}

		p {
			text-align: justify;
		}

		.table-container {
			width: 75%;
			margin: auto;
			display: block;
			color: #333;
		}

		.table-report {
			background-color: #fff;
			border-collapse: collapse;
			border: 1px solid #ccc;
			box-shadow: 0px 0px 10px -3px #000;
			text-align: left;
			font-family: 'Rubik', sans-serif;
			width: 100%;
		}

		.table-report th,
		.table-report td {
			border:1px solid #ccc;
			text-align: left;
			padding: .5em;
		}

		.table-report td {
			text-align: center;
		}

		.description {
			color: #555;
		}

	</style>
</head>
<body>
	<?php echo date("d-m-Y") ?>
	<h1 class="title">Reporte de roles</h1>
	<hr>
	<p>A continuación se presenta información general a cerca de los roles que son manejados en <i>domii.me</i></p>
	<div class="table-container">
		<table class="table-report">
			<?php if(isset($listRoles)): ?>
				<?php foreach ($listRoles as $rolesData): ?>
					<tr> <td><?php echo $rolesData['name_rol'] ?></td> </tr>
				<?php endforeach ?>
			<?php endif ?> 
		</table>
	</div>
	<h2>Sobre el rol Administrador</h2>
	<p>Privilegios, permisos y/o acciones permitidas</p>
	<ul>
		<li>Activar y desactivar usuarios</li>
		<li>Activar y desactivar empresas</li>
	</ul>
	<h2>Sobre el rol Empresario</h2>
	<p>Privilegios, permisos y/o acciones permitidas</p>
	<ul>
		<li>Registrar, editar y eliminar productos</li>
		<li>Comprar productos de otras empresas</li>
	</ul>
	<h2>Sobre el rol Cliente</h2>
	<p>Privilegios, permisos y/o acciones permitidas</p>
	<ul>
		<li>Comprar en cualquier empresas</li>
		<li>Convertirse en empreario al registrar su empresa</li>
	</ul>
</body>
</html>