<?php
session_start();
require_once("../../administrators/model/administrators.php");
$administrator = new Administrator();
$numUsers = $administrator->getNumUsers();
$numActiveUsers = $administrator->getNumActiveUsers();
$numDesactivatedUsers = $administrator->getNumDesactivatedUsers();
$numBusinessUsers = $administrator->getNumBusinessUsers();
$numClientsUsers = $administrator->getNumClientsUsers();
$numAdiminUsers = $administrator->getNumAdiminUsers();
?>


<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="../../public/img/favicon.png">
	<title>Reporte de usuarios</title>
	<style>

		body {
			font-family: sans-serif;
			color: #4C4C4C;
		}

		p {
			text-align: justify;
		}

		.table-container {
			width: 75%;
			margin: auto;
			display: block;
			color: #333;
		}

		.table-report {
			background-color: #fff;
			border-collapse: collapse;
			border: 1px solid #ccc;
			box-shadow: 0px 0px 10px -3px #000;
			text-align: left;
			font-family: 'Rubik', sans-serif;
			width: 100%;
		}

		.table-report th,
		.table-report td {
			border:1px solid #ccc;
			text-align: left;
			padding: .5em;
		}

		.table-report td {
			text-align: center;
		}

		.description {
			color: #555;
		}

	</style>
</head>
<body>
	<?php echo date("d-m-Y") ?>
	<h1 class="title">Reporte de usuarios</h1>
	<hr>
	<p>A continuación se presenta información general a cerca de los usuarios que actualmente se encuentran registrados en <i>domii.me</i></p>
	<div class="table-container">
		<table class="table-report">
			<tr> <th>Número total de usuarios</th> <td><?php echo strval($numUsers) ?> </td> </tr>
			<tr> <th>Usuarios activos</th> <td><?php echo $numActiveUsers ?></td> </tr>
			<tr> <th>Usuarios inactivos</th> <td><?php echo $numDesactivatedUsers ?></td> </tr>
			<tr> <th>Usuarios con rol administrador</th> <td><?php echo $numAdiminUsers ?></td> </tr>
			<tr> <th>Usuarios con rol empresario</th> <td><?php echo $numBusinessUsers ?></td> </tr>
			<tr> <th>Usuarios con rol cliente</th> <td><?php echo $numClientsUsers ?></td> </tr>
		</table>
	</div>
</body>
</html>