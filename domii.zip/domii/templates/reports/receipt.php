<?php
require_once("../../public/plugins/dompdf/vendor/autoload.php");
require_once("../../users/model/users.php");
require_once("../../orders/model/orders.php");
$user = new User();
$order = new Order();
$user->validateSession();
$id_user = $user->getId();
$orderData = $order->getInfo($id_user);
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset='UTF-8'>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>

		body {
			font-family: sans-serif;
			color: #4C4C4C;
		}

		p {
			text-align: justify;
		}

		.table-order-container {
			width: 75%;
			margin: auto;
			display: block;
			color: #333;
		}

		.table-order {
			background-color: #fff;
			border-collapse: collapse;
			border: 1px solid #ccc;
			box-shadow: 0px 0px 10px -3px #000;
			text-align: left;
			font-family: 'Rubik', sans-serif;
			width: 100%;
		}

		.caption {
			display: block;
			width: 100%;
			padding: 0.5em;
			text-align: center;
			color: #fff;
			background-color: #005db7;
		}

		.table-order th,
		.table-order td {
			border:1px solid #ccc;
			text-align: left;
			padding: .5em;
		}

		.description {
			color: #555;
		}

	</style>

</head>
<body>
	<?php echo date("d-m-Y") ?>
	<h1 class="title">¡Tu pedido fue enviado!</h1>
	<hr>
	<p>Hemos enviado exitosamente el pedido a la empresa que se lo solicitaste. Aquí te dejamos un resumen de lo que pediste:</p>
	<div class="table-order-container">
		<table class='table-order'>
			<caption class="caption">Detalles del pedido</caption>
			<tbody>
				<tr>
					<th>Cliente</th>
					<td><?php echo $orderData['name_user'] ?></td>
				</tr>
				<tr>
					<th>Teléfono</th>
					<td><?php echo $orderData['phone_order'] ?></td>
				</tr>
				<tr>
					<th>Dirección</th>
					<td><?php echo $orderData['address_order'] ?></td>
				</tr>
				<tr>
					<th>Fecha</th>
					<td><?php echo $orderData['date_order'] ?></td>
				</tr>
				<tr>
					<th>Producto</th>
					<td><?php echo $orderData['name_product'] ?></td>
				</tr>
				<tr>
					<th>Descripción</th>
					<td><?php echo $orderData['description_product'] ?></td>
				</tr>
				<tr>
					<th>Cantidad</th>
					<td><?php echo $orderData['quantity_product'] ?></td>
				</tr>
				<tr>
					<th>Precio unitario</th>
					<td>$ <?php echo $orderData['price_product'] ?></td>
				</tr>
				<tr>
					<th>Total</th>
					<td>$ <?php echo $orderData['total_order'] ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<p class="description">*<i>domii.me</i> es un intermediario entre las PyMES (pequeñas y medianas empresas) y sus clientes que presta un servicio gratuito de notificaciones sobre solicitudes de sus productos para ser llevados a domicilio.</p>
</body>
</html>