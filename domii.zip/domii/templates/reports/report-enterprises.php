<?php

	require_once("../../administrators/model/administrators.php");
	$administrator = new Administrator();
	$numEnterprises = $administrator->getNumEnterprises();
	$numActivatedEnterprises = $administrator->getNumActivatedEnterprises();
	$numDesactivatedEnterprises = $administrator->getNumDesactivatedEnterprises();
?>



<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" href="../../public/img/favicon.png">
	<title>Reporte de empresas</title>
	<style>

		body {
			font-family: sans-serif;
			color: #4C4C4C;
		}

		p {
			text-align: justify;
		}

		.table-container {
			width: 75%;
			margin: auto;
			display: block;
			color: #333;
		}

		.table-report {
			background-color: #fff;
			border-collapse: collapse;
			border: 1px solid #ccc;
			box-shadow: 0px 0px 10px -3px #000;
			text-align: left;
			font-family: 'Rubik', sans-serif;
			width: 100%;
		}

		.table-report th,
		.table-report td {
			border:1px solid #ccc;
			text-align: left;
			padding: .5em;
		}

		.table-report td {
			text-align: center;
		}

		.description {
			color: #555;
		}

	</style>
</head>
<body>
	<?php echo date("d-m-Y") ?>
	<h1 class="title">Reporte de empresas</h1>
	<hr>
	<p>A continuación se presenta información general a cerca de las empresas que actualmente se encuentran registrados en <i>domii.me</i></p>
	<div class="table-container">
		<table class="table-report">
			<tr> <th>Número total de empresas</th> <td><?php echo $numEnterprises ?> </td> </tr>
			<tr> <th>Empresas activas</th> <td><?php echo $numActivatedEnterprises ?> </td> </tr>
			<tr> <th>Empresas inactivas</th> <td><?php echo $numDesactivatedEnterprises ?> </td> </tr>
		</table>
	</div>
	<p>Las empresas que estén inactivas no serán listadas en el home de <i>domii.me</i>, por lo que los usuarios con rol <i>cliente</i> no podrán solicitar sus productos.</p>
</body>
</html>