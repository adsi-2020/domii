<div class="group">
	<div class="box">
		<div class="modal-container is-hidden" id="loaderModal">
			<div class="loader"></div>
		</div>
	</div>
</div>