<nav>
	<ul class="main-menu" id="mainMenu">
		<?php if ($user->isLoged() && strtoupper($user->getRol()) != "ADMINISTRADOR"): ?>
			<li class="main-menu__item">
				<a href="/domii/home/index.php" class="main-menu__link">
					<i class="icon-home"></i>
					Inicio
				</a>
			</li>
		<?php endif ?>
		<?php if ($user->isLoged() && strtoupper($user->getRol()) == "CLIENTE"): ?>
			<li class="main-menu__item">
				<a href="/domii/empresas/views/add.php" class="main-menu__link">
					<i class="icon-star"></i>
					¡Registra tu empresa!
				</a>
			</li>
		<?php endif ?>
		<?php if ($user->isLoged() && strtoupper($user->getRol()) == "EMPRESARIO"): ?>
		<li class="main-menu__item">
			<a href="#" class="main-menu__link link-my-enterprise">
				<i class="icon-enterprise"></i>
				Mi empresa
			</a>
			<ul class="main-menu--submenu">
				<li class="main-menu--submenu__item">
					<a href="/domii/empresas/views/addproduct.php" class="main-menu--submenu__link">
						<i class="icon-plus"></i>
						Agregar producto
					</a>
				</li> 
			</ul>
		</li>
		<?php endif ?>
		<?php if ($user->isLoged() && strtoupper($user->getRol()) != "ADMINISTRADOR"): ?>
			<li class="main-menu__item">
				<a href="../home/about.php" class="main-menu__link">
					<i class="icon-info"></i>
					A cerda de
				</a>
			</li>
		<?php endif ?>
		<?php if ($user->isLoged()): ?>
		<li class="main-menu__item">
			<a href="/domii/public/plugins/google_auth/logout.php" class="main-menu__link">
				<i class="icon-power"></i>
				Salir
			</a>
		</li>
	<?php endif ?>
	</ul>
</nav>