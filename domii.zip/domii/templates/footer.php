<footer class="main-footer">
	<div class="group">
		<div class="box">
			<p>Desarrollado por: &#128640;</p>
			<p>&#128187; Carlos Mario Ramos Pérez</p>
			<p>&#128187; Luis Ferney Medina Guzmán</p>
			<p>Todos los derechos reservados &copy; 2020</p>
		</div>
	</div>
</footer>