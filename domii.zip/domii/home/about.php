<?php
	session_start();
	require_once("../users/model/users.php");
	$user = new User();
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>A cerca de</title>
	<link rel="stylesheet" href="../public/css/styles.css">
</head>
<body>
	<?php include("../templates/main-header.php") ?>
	<?php include("../templates/main-menu.php") ?>
	<section class="section-about-domii">
		<div class="group">
			<div class="box">
				<div class="section-about-domii__item">
					<h2 class="section-about-domii__title">A cerca de</h2>
					<p><i>En domii</i> tenemos como objetivo <span>conectar a las PyMES (pequeñas y medianas empresas) con sus clientes.</span> El servicio que ofrecemos es netamente notificativo, es decir, que <i>domii</i> se fundamenta en brindar un servicio que le permite a las empresas recibir mediante correo electrónico información sobre solicitudes de sus productos para ser llevados a domicilio, y es la empresa que ofrece el producto quien se encarga de realizarlo (el domicilio). Al usar domii optienes las siguientes ventajas:</p>
					<p>
						<i class="icon-check"></i>
						Evitas manejar tu empresa por chat convencional atendiendo a múltiples clientes al mismo tiempo.
					</p>
					<p>
						<i class="icon-check"></i>
						Evitas recibir llamadas y mensajes simultáneamente.
					</p>
					<p>
						<i class="icon-check"></i>
						Recibes toda la información necesaria sobre el pedido con los datos de tu cliente. ¡Hasta puedes imprimirlos!
					</p>
					<p>¿Quieres saber cómo funciona? Haz click <a href="manual.php">aquí.</a></p>
				</div>
			</div>
		</div>
	</section>
	<?php include("../templates/footer.php") ?>
	<script src="../public/js/main.js"></script>
</body>
</html>