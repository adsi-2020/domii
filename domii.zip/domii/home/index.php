<?php

	session_start();
	require_once('../empresas/model/enterprises.php');
	require_once('../users/model/users.php');
	$user = new User();
	$user->validateSession();
	$enterprise = new Enterprise();
	$listEnterprises = $enterprise->getEnterprises();
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Inicio</title>
	<link rel="icon" href="../public/img/favicon.png">
	<link rel="stylesheet" href="../public/css/styles.css">
</head>
<body>
	<?php include("../templates/main-header.php")?>
	<?php include("../templates/main-menu.php") ?>
	<div class="group">
		<?php if (isset($listEnterprises)): ?>
			<?php foreach ($listEnterprises as $enterprise): ?>
				<div class="box">
					<div class="card card-enterprise">
						<a href="../empresas/views/index.php?id=<?php echo $enterprise['id_enterprise'] ?>">
							<?php $path_img_profile_enterprise = "../public/img/{$enterprise['img_enterprise']}"; ?>
							<img src="<?php echo $path_img_profile_enterprise ?>" alt="" class="card-enterprise__img">
							<h2 class="card-enterprise__title"><?php echo $enterprise['name_enterprise'] ?></h2>
						</a>
						<p class="card-enterprise__description"><?php echo $enterprise['description_enterprise']; ?></p>
					</div>
				</div>
			<?php endforeach ?> 
		<?php endif ?>
	</div>
	<?php include "../templates/footer.php" ?>
	<script src="../public/js/jQuery/jquery-3.5.1.min.js"></script>
	<script src="../public/js/main.js"></script>
</body>
</html>