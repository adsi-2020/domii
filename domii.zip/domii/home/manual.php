<?php
	header("Content-type: application/pdf");
	header("Content-Disposition: inline; filename=manual_usuario.pdf");
	readfile("../templates/manual_usuario.pdf");
?>