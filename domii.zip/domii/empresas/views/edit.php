<?php 
	
	session_start();
	require_once('../model/enterprises.php');
	require_once('../../products/model/products.php');
	require_once("../../users/model/users.php");
	$user = new User();
	$user->validateSession();
	$product = new Product();
	$enterprise = new Enterprise();
	$id_enterprise = $_GET['id'];
	$enterpriseData = $enterprise->getById($id_enterprise);
?> 
<!DOCTYPE html>
<html>
<head> 
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Editar empresa</title>
	<link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
	<?php include("../../templates/main-header.php")?>
	<?php include("../../templates/main-menu.php")?>  
	<div class="group">
		<div class="box">
			<form action="../controller/edit.php" method="POST" class="form-edit--enterprise" id="formEditEnterprise" enctype="multipart/form-data">
				<h2 class="form__title">Modificar Empresa</h2>
				<input type="hidden" name="id_enterprise" value="<?php echo $id_enterprise ?>">
				<fieldset>
					<legend>Nombre de la empresa</legend>  
					<input type="text" name="name" required="" autocomplete="off" value="<?php echo $enterpriseData['name_enterprise'] ?> ">
				</fieldset>
				<fieldset>
					<legend>Descripción de la empresa</legend>  
					<input type="text" name="description" required="" autocomplete="off" value="<?php echo $enterpriseData['description_enterprise'] ?> ">
				</fieldset>
				<fieldset>
					<legend>Propietario</legend>
					<input type="text" name="owner" required="" autocomplete="off" value="<?php echo $enterpriseData['owner_enterprise'] ?> ">
				</fieldset>
				<fieldset>
					<legend>Dirección de la empresa</legend>
					<input type="text" name="address" required="" autocomplete="off" value="<?php echo $enterpriseData['address_enterprise'] ?>">
				</fieldset>
				<fieldset>
					<legend>Correo electronico </legend>
				<input type="email" name="email" required="" autocomplete="off" value="<?php echo $enterpriseData['email_enterprise'] ?>">
				</fieldset>
				<fieldset>
					<legend>Telefono de la empresa</legend>
				<input type="phone" name="phone" required="" autocomplete="off"  value="<?php echo $enterpriseData['phone_enterprise'] ?>">
				</fieldset>
				<fieldset>
					<legend>Logo de tu empresa</legend> 
				<input type="file" name="image" required value="<?php echo $enterpriseData['img_enterprise'] ?>">
				</fieldset>
				<input type="submit" value="Modificar" > 
			</form>
		</div>
	</div>
	<script src="../../public/js/jQuery/jquery-3.5.1.min.js"></script>
	<script src="../../public/js/main.js"></script>
</body>
</html>