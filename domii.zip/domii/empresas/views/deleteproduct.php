<?php
	session_start();
	require_once("../../products/model/products.php");
	require_once("../../users/model/users.php");
	$product = new Product();
	$user = new User();
	$user->validateSession();
	$id = $_GET['id'];
 ?>
 
<!DOCTYPE html> 
<html>  
<head> 
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Eliminar</title>
	<link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
	<?php include("../../templates/main-header.php")?>
	<?php include("../../templates/main-menu.php")?> 
	<div class="group">
		<div class="box">
			<form action="../../products/controller/delete.php" method="POST" class="form-delete--product" id="formDeleteProduct">
				<h2 class="form__title">Eliminar Producto</h2>
				<input type="hidden" name="id" value="<?php echo $id ?>">
				<p class="form__description">¿Estás seguro que deseas eliminar éste producto?</p>
				<input type="submit" value="Sí, eliminar">
			</form>
		</div>
	</div>
	<script src="../../public/js/jQuery/jquery-3.5.1.min.js"></script>
	<script src="../../public/js/main.js"></script>
</body>
</html>