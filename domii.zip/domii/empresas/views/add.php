<?php

	session_start();
	require_once("../../users/model/users.php");
	$user = new User();
	$user->validateSession();
	$id_user = $user->getId();
?>

<!DOCTYPE html>
<html>
<head> 
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Registrar empresa</title>
	<link rel="icon" href="../../public/img/favicon.png">
	<link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
	<?php include("../../templates/main-header.php")?>
	<?php include("../../templates/main-menu.php")?>
	<div class="group">
		<div class="box">
			<form action="../controller/add.php" method="POST" class="form-register--enterprise" id="formRegisterEnterprise" enctype="multipart/form-data">
				<input type="hidden" name="id_user" value="<?php echo $id_user ?>">
				<h2 class="form__title">Registrar Empresa</h2>
				<fieldset>
					<legend>Nombre de la empresa</legend>
					<input type="text" name="name" required="" autofocus autocomplete="off">
				</fieldset>
				<fieldset>
					<legend>Descripción</legend>
					<input type="text" name="description" required="" autocomplete="off">
				</fieldset>
				<fieldset>
					<legend>Propietario</legend>
					<input type="text" name="owner" required="" autocomplete="off">
				</fieldset>
				<fieldset>
					<legend>Dirección de la empresa</legend>
					<input type="text" name="address" required="" autocomplete="off">
				</fieldset>
				<fieldset>
					<legend>Correo electronico </legend>
					<input type="email" name="email" required="" autocomplete="off" placeholder="Aquí llegarán tus pedidos">
				</fieldset>
				<fieldset>
					<legend>Telefono de la empresa</legend>
					<input type="phone" name="phone" required="" autocomplete="off">
				</fieldset>
				<fieldset>
					<legend>Logo de tu empresa</legend> 
					<input type="file" name="image" required="" autocomplete="off">
				</fieldset>
				<input type="submit" value="Registrar empresa">
			</form>
		</div>
	</div>
	<script src="../../public/js/jQuery/jquery-3.5.1.min.js"></script>
	<script src="../../public/js/main.js"></script> 
</body>
</html>