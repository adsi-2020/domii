<?php
	session_start();
	require_once("../../users/model/users.php");
	require_once("../../products/model/products.php");
	require_once('../model/enterprises.php');
	$user = new User;
	$user->validateSession();
	$enterprise = new Enterprise();
	$product = new Product();
	$id_enterprise = $_GET['id'];
	$id_user = $user->getId();
	$enterpriseData = $enterprise->getById($id_enterprise);
	$img_enterprise = $enterprise->getImg($id_enterprise);
	$path_img_enterprise = "../../public/img/{$img_enterprise}";
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Productos</title>
	<link rel="icon" href="../../public/img/favicon.png">
	<link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
	<?php include("../../templates/main-header.php") ?>
	<?php include("../../templates/main-menu.php") ?>
	<?php include("../../templates/loader-modal.php") ?>
	<section class="profile-enterprise">
		<div class="group">
			<div class="box"> 
				<div class="card-product__menu-product">
					<?php if ($user->isOwner($id_user, $id_enterprise)): ?>
						<i class="icon-points iconPoints"></i>
					<?php endif ?>
					<div class="items is-hidden">
						<a href="../../empresas/views/delete.php?id=<?php echo $enterpriseData['id_enterprise'] ?>">Eliminar</a>
						<a href="../../empresas/views/edit.php?id=<?php echo $enterpriseData['id_enterprise'] ?>">Editar</a>
					</div>
				</div>
				<img src="<?php echo $path_img_enterprise ?>" alt="Imagen de la empresa" class="profile-enterprise__img">
				<h2 class="profile-enterprise__name"><?php echo $enterpriseData['name_enterprise']; ?></h2>
				<p class="profile-enterprise__address">
					<i class="icon-location"></i>
					<?php echo $enterpriseData['address_enterprise']; ?>
				</p>
				<p class="profile-enterprise__email">
					<i class="icon-email"></i>
					<?php echo $enterpriseData['email_enterprise']; ?>
				</p>
				<p class="profile-enterprise__phone">
					<i class="icon-phone"></i>
					<?php echo $enterpriseData['phone_enterprise']; ?>
				</p>
			</div>
		</div>
	</section>
	<?php $listProducts[] = $enterprise->getProducts($id_enterprise) ?>
	<div class="group">
		<?php if (isset($listProducts)): ?>
			<?php foreach ($listProducts as $product): ?>
				<?php if (isset($product)): ?>
					<?php foreach ($product as $productData): ?>
						<div class="box">
							<div class="card-product">
								<div class="card-product__menu-product">
									<?php if ($user->isOwner($id_user, $id_enterprise)): ?>
										<i class="icon-points iconPoints"></i>
									<?php endif ?>
									<div class="items is-hidden">
										<a href="../../empresas/views/deleteproduct.php?id=<?php echo $productData['id_product'] ?>">Eliminar</a>
										<a href="../../empresas/views/editproduct.php?id=<?php echo $productData['id_product'] ?>">Editar</a>
									</div>
								</div>
								<?php $path_img_product = "../../public/img/{$productData['img_product']}"; ?>
								<img src="<?php echo $path_img_product ?>" class="card-product__img">
								<p class="card-product__description">
									<i class="icon-check"></i>
									<?php echo $productData['description_product'] ?>
								</p>
								<div class="card-product__buttons">
									<p class="card-product__price">
										<i class="icon-ticket"></i>
										<?php echo "$ {$productData['price_product']}" ?>
									</p>
									<?php if (!$user->isOwner($id_user, $id_enterprise)): ?>
										<button class="btn-buy">Pedir</button>
									<?php endif ?>
									<div class="buy-product-form is-hidden">
										<form action="../../orders/controller/add.php" method="POST" class="formBuy">
											<input type="hidden" name="id_user" value="<?php echo $id_user ?>">
											<input type="hidden" name="id_product" value="<?php echo $productData['id_product'] ?>">
											<input type="hidden" name="price_product" value="<?php echo $productData['price_product'] ?>">
											<input type="hidden" name="id_enterprise" value="<?php echo $id_enterprise ?>">
											<input type="text" name="address_order" required autofocus autocomplete="off" placeholder="Danos una dirección">
											<input type="number" min="3" name="phone_order" required autocomplete="off" placeholder="Danos un teléfono">
											<input type="number" name="quantity_product" min="1" required autocomplete="off" placeholder="Danos una cantidad">
											<p class="form__description">
												<i class="icon-info"></i>
												El pago es contra entrega y domii no se hace responsable de la entrega del producto. Ésta es realizada por la empresa que lo ofrece.
											</p>
											<input type="submit" value="Aceptar" class="btnBuyProduct">
										</form>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach ?>
				<?php endif ?>
			<?php endforeach ?>
		<?php endif ?>
	</div>
	<?php include "../../templates/footer.php" ?>
	<script src="../../public/js/jQuery/jquery-3.5.1.min.js" ></script>
	<script src="../../public/js/main.js"></script>
</body>
</html>