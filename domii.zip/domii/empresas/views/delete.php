<?php	
	session_start();
	require_once('../model/enterprises.php');
	require_once('../../users/model/users.php');
	$user = new User();
	$user->validateSession();
	$enterprise = new Enterprise();
	$id_enterprise = $_GET['id']; 
?>
<!DOCTYPE html>
<html>   
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Eliminar producto</title>
	<link rel="icon" href="../../public/img/favicon.png">
	<link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body>
	<?php include("../../templates/main-header.php")?>
	<?php include("../../templates/main-menu.php")?> 
	<div class="group">
		<div class="box">
			<form action="../controller/delete.php" method="POST" class="form-delete--enterprise" id="formDeleteEnterprise">
				<h2 class="form__title">Eliminar tu empresa</h2>
				<i class="icon-trash form__img"></i>
				<input type="hidden" name="id_enterprise" value="<?php echo $id_enterprise ?>">
				<p class="form__description">¿Estás seguro que deseas eliminar tu empresa de domii?</p>
				<input type="submit" value="Sí, eliminar">
			</form>
		</div>
	</div>
	<script src="../../public/js/jQuery/jquery-3.5.1.min.js"></script>
	<script src="../../public/js/main.js"></script>
</body>
</html>