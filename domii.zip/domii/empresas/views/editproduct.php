<?php 

	session_start();
	require_once('../../products/model/products.php');
	require_once("../../users/model/users.php");
	require_once("../../empresas/model/enterprises.php");
	$user = new User();
	$user->validateSession();
	$product = new Product();
	$id_product = $_GET['id'];
	$enterprise = new Enterprise();
	$id_user = $user->getId();
	$id_enterprise = $enterprise->getId($id_user);
	$productData = $product->getById($id_product);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
	<title>Editar Producto</title>
	<link rel="icon" href="../../public/img/favicon.png">
	<link rel="stylesheet" href="../../public/css/styles.css">
</head>
<body> 
	<?php include("../../templates/main-header.php")?>
	<?php include("../../templates/main-menu.php")?>  
	<div class="group"> 
		<div class="box">
			<form action="../../products/controller/edit.php" method="POST" class="form-registerProduct--enterprise" id="formRegisterProduct" enctype="multipart/form-data">
				<input type="hidden" name="id_product" value="<?php echo $id_product ?>">
				<input type="hidden" name="id_enterprise" value="<?php echo $id_enterprise ?> ">
				<fieldset>
					<legend>Nombre del producto</legend>
					<input type="text" name="name" required="" autocomplete="off" value="<?php echo $productData['name_product'] ?> ">
				</fieldset> 
				<fieldset> 
					<legend>Descripción del producto</legend>
					<input type="text" name="description" required="" autocomplete="off" value="<?php echo $productData['description_product'] ?> ">
				</fieldset>
				<fieldset>
					<legend>Precio del producto</legend>
					<input type="number" name="price" min="100" required="" autocomplete="off" value="<?php echo $productData['price_product'] ?> ">
				</fieldset>
				<fieldset>  
					<legend>Sube una imagen de producto</legend>
					<input type="file" name="image" required>
				</fieldset>
				<input type="submit" value="Editar" > 
			</form> 
		</div>
	</div>
	<script src="../../public/js/jQuery/jquery-3.5.1.min.js"></script>
	<script src="../../public/js/main.js"></script> 
</body>
</html>