<?php
	session_start();
	require_once("../../users/model/users.php");
	$user = new User();
	$id_enterprise = $_GET['id'];
	$user->validateSession();
?>

<?php
	require_once("../../public/plugins/dompdf/vendor/autoload.php");
	
	use Dompdf\Dompdf;

	// instantiate and use the dompdf class
	$dompdf = new Dompdf();
	ob_start();
	require_once "../../templates/reports/receipt.php";
	$content = ob_get_clean();
	$dompdf->loadHtml($content);

	// (Optional) Setup the paper size and orientation
	$dompdf->setPaper('A4', 'portrait');

	// Render the HTML as PDF
	$dompdf->render();

	$dompdf->stream("dompdf_out.pdf", array("Attachment" => false));

	// Output the generated PDF to Browser
	$dompdf->stream();
?>