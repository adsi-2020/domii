<?php 

session_start();
require_once("../model/enterprises.php");
require_once("../../users/model/users.php");
$user = new User();
$id_user = $user->getId();

if ($_POST) 
{
	$enterprise = new Enterprise();
	$id_enterprise = $_POST['id_enterprise'];



	if ($enterprise->hide($id_enterprise))  
	{
		header('location: ../../home/index.php'); 
	}


	else  
	{
		header('location: ../views/index.php');  
	}

}

else
{
	header('location: ../views/index.php'); 
}
?>