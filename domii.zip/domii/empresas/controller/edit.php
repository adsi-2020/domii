<?php

	require_once("../model/enterprises.php");

	if ($_POST) 
	{
		$enterprises = new Enterprise();
		
		$id_enterprise = $_POST['id_enterprise'];
		$name = $_POST['name'];
		$owner = $_POST['owner']; 
		$address = $_POST['address']; 
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$description = $_POST['description'];
		$name_img = $_FILES['image']['name'];
		$typeImg = $_FILES['image']['type'];
		$sizeImg = $_FILES['image']['size'];

		if ($sizeImg<=5000000)
		{
			if ($typeImg== "image/jpeg" || $typeImg=="image/jpg" || $typeImg=="image/png" || $typeImg=="image/gif")
			{
				//ruta de la carpeta de destino en el servidor
				$target = $_SERVER['DOCUMENT_ROOT'] . '/domii/public/img/'; 

				//movemos la imagen del directorio temporal a el directorio de destino original 
				move_uploaded_file($_FILES['image']['tmp_name'], $target . $name_img);
			}

			else
			{
				echo "Solo se pueden subir imagenes con extenciones tipo: jpeg/jpg/png/gif";
			}
		}

		else
		{
			echo "El archivo supera el limite del tamaño";
		}

		if($enterprises->update($id_enterprise, $name, $description, $owner, $address, $email, $phone, $name_img))
		{
			header("location: ../views/index.php?id={$id_enterprise}");
		}

		else
		{
			header('location: ../views/index.php'); 
		}

	}

	else
	{
		header('location: ../views/index.php');  
	}
?>