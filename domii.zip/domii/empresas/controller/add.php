<?php 

	session_start();
	require_once("../model/enterprises.php");
	require_once("../../users/model/users.php");
	$enterprise = new Enterprise();
	$user = new User();
	$id_user = $user->getId();

	if ($_POST)
	{
		$enterprises = new Enterprise();

		$name = $_POST['name'];
		$description = $_POST['description'];
		$owner 	 = $_POST['owner']; 
		$address = $_POST['address'];
		$email 	 = $_POST['email'];
		$phone 	 = $_POST['phone'];
		$active = 1;
		$id_user = $_POST['id_user']; 
		$nameImg=$_FILES['image']['name'];
		$typeImg=$_FILES['image']['type'];
		$sizeImg=$_FILES['image']['size']; 

		if ($sizeImg<=5000000) { 

			if ($typeImg== "image/jpeg" || $typeImg=="image/jpg" || $typeImg=="image/png" || $typeImg=="image/gif"){ 

			//ruta de la carpeta de destino en el servidor
				$target = $_SERVER['DOCUMENT_ROOT'] . '/domii/public/img/'; 

			//movemos la imagen del directorio temporal a el directorio de destino original 
				move_uploaded_file($_FILES['image']['tmp_name'], $target . $nameImg);
			}

			else
			{
				echo "Solo se pueden subir imagenes con extenciones tipo: jpeg/jpg/png/gif";
			}
		}
 
		else
		{
			echo "El archivo supera el limite del tamaño";
		}

		if($enterprises->add($name, $description, $owner, $address, $email, $phone, $id_user, $nameImg, $active))
		{	$id_rol = 3;
			$id_enterprise = $enterprise->getId($id_user);
			if($user->changeRol($id_user, $id_rol) && $user->setEnterprise($id_enterprise, $id_user))
			{
				header('location: ../../home/index.php');
			}
		}

		else
		{ 
			header('location: ../views/index.php'); 
		}

	}

	else
	{
		header('location: ../views/index.php'); 
	}
?>