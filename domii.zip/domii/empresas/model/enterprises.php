<?php

	require_once("C:/xampp/htdocs/domii/app/Connection.php"); 

	class Enterprise extends Connection  
	{ 
		public function __construct()
		{  
			$this->db = parent::__construct(); 
		}   

		public function add($name, $description, $owner, $address, $email, $phone, $id_user, $nameImg, $active)
		{
			$statement = $this->db->prepare("INSERT INTO enterprises (name_enterprise, description_enterprise, owner_enterprise, address_enterprise, email_enterprise, phone_enterprise, id_user, img_enterprise, active) VALUES (:name, :description, :owner, :address, :email, :phone, :id_user, :image, :active)");

			$statement->bindParam(":name", $name);
			$statement->bindParam(":owner", $owner);
			$statement->bindParam(":address", $address);
			$statement->bindParam(":email", $email);
			$statement->bindParam(":phone", $phone);
			$statement->bindParam(":id_user", $id_user);
			$statement->bindParam(":image", $nameImg);
			$statement->bindParam(":description", $description);
			$statement->bindParam(":active", $active); 
			return ($statement->execute()) ? true : false;

		}

		public function getEnterprises()
		{
			$statement = $this->db->prepare("SELECT * FROM enterprises WHERE active = 1");
			$statement->execute(); 

			while ($dataEnterprise = $statement->fetch())
			{
				$rows[] = $dataEnterprise;
			} 

			return isset($rows) ? $rows : null;
		}
		
		public function getProducts($id_enterprise)
		{
			$sql = "SELECT * FROM products WHERE id_enterprise = :id_enterprise";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_enterprise", $id_enterprise);
			$stmt->execute();

			while ($result = $stmt->fetch())
			{
			    $listProducts[] = $result;
			}

			return isset($listProducts) ? $listProducts : null;
		}

		
		public function getById($id)
		{
			$statement = $this->db->prepare("SELECT * from enterprises WHERE id_enterprise = :id");
			$statement->bindParam(":id", $id);
			$statement->execute();

			while ($dataEnterprise = $statement->fetch())
			{
				$rows = $dataEnterprise;
			}

			return $rows;
		}
		
		public function update($id_enterprise, $name, $description, $owner, $address, $email, $phone, $image)
		{
			$statement = $this->db->prepare("UPDATE enterprises
											 SET name_enterprise = :name,
											 description_enterprise = :description,
											 owner_enterprise = :owner,
											 address_enterprise = :address,
											 email_enterprise = :email, 
											 phone_enterprise = :phone,
											 img_enterprise = :image
											 WHERE id_enterprise = :id_enterprise");

			$statement->bindParam(":id_enterprise", $id_enterprise);
			$statement->bindParam(":name", $name);
			$statement->bindParam(":description", $description);
			$statement->bindParam(":owner", $owner);
			$statement->bindParam(":address", $address);
			$statement->bindParam(":email", $email);
			$statement->bindParam(":phone", $phone);
			$statement->bindParam(":image", $image);

			return ($statement->execute()) ? true : false; 
		}

		public function hide($id_enterprise)
		{
			$statement = $this->db->prepare("UPDATE enterprises SET active = 0 WHERE id_enterprise = :id_enterprise");
			$statement->bindParam(":id_enterprise", $id_enterprise);
			return ($statement->execute()) ? true : false; 
		}

		public function getImg($id_enterprise)
		{
			$statement = $this->db->prepare("SELECT img_enterprise FROM enterprises WHERE id_enterprise = :id_enterprise");
			$statement->bindParam(":id_enterprise", $id_enterprise);
			$statement->execute();

			while ($result = $statement->fetch())
			{
				$img = $result;
			}

			return $img[0];
		}

		public function getId($id_user)
		{
			$statement = $this->db->prepare("SELECT id_enterprise FROM enterprises WHERE id_user = :id_user");
			$statement->bindParam(":id_user", $id_user);
			$statement->execute();

			while ($result = $statement->fetch())
			{
				$id = $result;
			}

			return $id[0];
		}

		public function deleteIdUser($id_enterprise)
		{
			$sql = "UPDATE enterprises SET id_user = null WHERE id_enterprise = :id_enterprise";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_enterprise", $id_enterprise);
			return ($stmt->execute()) ? true : false;
		}
	}
?>