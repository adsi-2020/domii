<?php
	
	require_once("../model/administrators.php");
	$administrator = new Administrator();
	$option = $_POST['option'];
	$id_user = $_POST['id_user'];
	$id_enterprise = $_POST['id_enterprise'];

	switch ($option)
	{
		case "enableUser":
			$administrator->enableUser($id_user);
			break;
		case "disableUser":
			$administrator->disableUser($id_user);
			break;
		case "disableEnterprise":
			$administrator->disableEnterprise($id_enterprise);
			break;
		case "enableEnterprise":
			$administrator->enableEnterprise($id_enterprise);
			break;
	}
?>












