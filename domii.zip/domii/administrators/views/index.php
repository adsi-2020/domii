<?php
session_start();
require_once("../../administrators/model/administrators.php");
require_once("../../users/model/users.php");
$user = new User();
$user->validateSessionAsAdministrator();
$administrator = new Administrator();
$listUsers = $administrator->getUsers();
$listRoles = $administrator->getRoles();
$listEnterprises = $administrator->getEnterprises();
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../../public/css/styles.css">
	<link rel="icon" href="../../public/img/favicon.png">
	<title>Administrador</title>
</head>
<body> 
	<?php include("../../templates/main-header.php") ?>
	<?php include("../../templates/main-menu.php") ?>
	<div class="tabs-container-admin">
		<ul class="tabs" id="tabs">
			<li class="tabs__item active">Usuarios</li>
			<li class="tabs__item">Empresas</li>
			<li class="tabs__item">Roles</li>
		</ul>
		<div class="panels">
			<div class="panels__item active">
				<a href="report-users.php" target="_blank" class="link">
					<i class="icon-printer"></i>
					Imprimir informe
				</a>
				<table class="table-info">
					<caption>Usuarios</caption>
					<thead>
						<tr>
							<th>ID</th>
							<th>Nombre</th>
							<th>Correo electrónico</th>
							<th>Rol</th>
							<th>Empresa</th>
							<th>Activo</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody>
						<?php if (isset($listUsers)): ?>
							<?php foreach ($listUsers as $userData): ?>
								<tr>
									<td><?php echo $userData['id_user'] ?></td>
									<td><?php echo $userData['name_user'] ?></td>
									<td><?php echo $userData['email_user'] ?></td>
									<td><?php echo $userData['id_rol'] ?></td>
									<td>
										<?php if (empty($userData['id_enterprise'])): ?>
											No aplica
											<?php else: ?>
												<?php echo $userData['id_enterprise'] ?>
											<?php endif ?>
										</td>
										<?php if ($userData['active'] == 1): ?>
											<td class="cell--enabled">Sí</td>
											<?php else: ?>
												<td class="cell--disabled">No</td>
											<?php endif ?>
											<td>
												<form action="../controller/functions.php" method="POST" class="formAdmin">
													<select name="option" class="formAdminSelect">
														<option disabled selected>--Seleccione--</option>
														<?php if ($userData['active'] == 1): ?>
															<option value="disableUser">Desactivar usuario</option>
															<?php else: ?>
																<option value="enableUser">Activar usuario</option>
															<?php endif ?>
														</select>
														<input type="hidden" name="id_user" value="<?php echo $userData['id_user'] ?>">
													</form>
												</td>
											</tr>
										<?php endforeach ?>
									<?php endif ?>
								</tbody>
							</table>
						</div>
						<div class="panels__item">
							<a href="report-enterprises.php" target="_blank" class="link">
								<i class="icon-printer"></i>
								Imprimir informe
							</a>
							<table class="table-info">
								<caption>Empresas</caption>
								<thead>
									<tr>
										<th>ID</th>
										<th>Nombre de la empresa</th>
										<th>Propietario</th>
										<th>Dirección</th>
										<th>Correo electronico</th>
										<th>Telefono</th>
										<th>Id usuario</th>
										<th>Activo</th>
										<th>Opciones</th>
									</tr>
								</thead>
								<tbody>
									<?php if(isset($listEnterprises)): ?>
										<?php foreach ($listEnterprises as $enterprisesData): ?>
											<tr>
												<td><?php echo $enterprisesData['id_enterprise'] ?></td>
												<td><?php echo $enterprisesData['name_enterprise'] ?></td>
												<td><?php echo $enterprisesData['owner_enterprise'] ?></td>
												<td><?php echo $enterprisesData['address_enterprise'] ?></td>
												<td><?php echo $enterprisesData['email_enterprise'] ?></td>
												<td><?php echo $enterprisesData['phone_enterprise'] ?></td>
												<td><?php echo $enterprisesData['id_user'] ?></td>
												<?php if ($enterprisesData['active'] == 1): ?>
													<td class="cell--enabled">Sí</td>
													<?php else: ?>
														<td class="cell--disabled">No</td>
													<?php endif ?>
													<td>
														<form action="../controller/functions.php" method="POST" class="formAdmin">
															<select name="option" class="formAdminSelect">
																<option disabled selected>--Seleccione--</option>
																<?php if ($enterprisesData['active'] == 1): ?>
																	<option value="disableEnterprise">Desactivar empresa</option>
																	<?php else: ?>
																		<option value="enableEnterprise">Activar empresa</option>
																	<?php endif ?>
																</select>
																<input type="hidden" name="id_enterprise" value="<?php echo $enterprisesData['id_enterprise'] ?>">
															</form>
														</td>
													</tr>
												<?php endforeach ?> 
											<?php endif ?> 
										</tbody>
									</table>
								</div>
								<div class="panels__item">
									<a href="report-roles.php" target="_blank" class="link">
										<i class="icon-printer"></i>
										Imprimir informe
									</a>
									<table class="table-info">
										<caption>Roles</caption>
										<thead>
											<tr>
												<th>ID</th>
												<th>Nombre rol</th>
											</tr>
										</thead>
										<tbody>
											<?php if(isset($listRoles)): ?>
												<?php foreach ($listRoles as $rolesData): ?>
													<tr>
														<td><?php echo $rolesData['id_rol'] ?></td>
														<td><?php echo $rolesData['name_rol'] ?></td>
													</tr>
												<?php endforeach ?> 
											<?php endif ?> 
										</tbody> 
									</table>
								</div>
							</div>
						</div>
						<?php include "../../templates/footer.php" ?>
						<script src="../../public/js/jQuery/jquery-3.5.1.min.js"></script>
						<script src="../../public/js/main.js"></script>
					</body>
					</html>