<?php

	require_once("C:/xampp/htdocs/domii/app/Connection.php");

	class Administrator extends Connection
	{
		public function __construct()
		{
			$this->db = parent:: __construct(); 
		} 
	 
		public function getEnterprises()
		{
			$sql = "SELECT * FROM enterprises";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			
			while ($dataEnterprises = $stmt->fetch())
			{
				$rows[] = $dataEnterprises;
			}

			return isset($rows) ? $rows : null;
		}

		public function getUsers()
		{	
			$sql = "SELECT * FROM users";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();

			while ($dataUsers = $stmt->fetch())
			{
				$rows[] = $dataUsers;
			}

			return isset($rows) ? $rows : null;
		}

		public function hideEnterprise($id_enterprise)
		{
			$sql = "UPDATE enterprises SET active = 0 WHERE id_enterprise = :id_enterprise";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_enterprise", $id_enterprise);
			return ($stmt->execute()) ? true : false;
		}

		public function hideUser($id_user)
		{
			$sql = "UPDATE users SET active = 0 WHERE id_user = :id_user";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_user", $id_user);
			return ($stmt->execute()) ? true : false;
		}

		public function getRoles()
		{
			$sql = "SELECT * FROM roles ";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();

			while ($result = $stmt->fetch())
			{
			    $listRoles[] = $result;
			}

			return isset($listRoles) ? $listRoles : null;
		}
		
		public function enableUser($id_user)
		{
			$sql = "UPDATE users SET active = 1 WHERE id_user = :id_user";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_user", $id_user);
			return ($stmt->execute()) ? header("location: ../views/index.php") : false;
		}

		public function disableUser($id_user)
		{
			$sql = "UPDATE users SET active = 0 WHERE id_user = :id_user";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_user", $id_user);
			return ($stmt->execute()) ? header("location: ../views/index.php") : false;
		}

		public function enableEnterprise($id_enterprise)
		{
			$sql = "UPDATE enterprises SET active = 1 WHERE id_enterprise = :id_enterprise";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_enterprise", $id_enterprise);
			return ($stmt->execute()) ? header("location: ../views/index.php") : false;
		}

		public function disableEnterprise($id_enterprise)
		{
			$sql = "UPDATE enterprises SET active = 0 WHERE id_enterprise = :id_enterprise";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_enterprise", $id_enterprise);
			return ($stmt->execute()) ? header("location: ../views/index.php") : false;
		}

		/*===============================================
		=            Reportes sobre usuarios            =
		===============================================*/
		

		public function getNumUsers()
		{
			$sql = "SELECT COUNT(*) FROM users";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}

		public function getNumActiveUsers()
		{
			$sql = "SELECT COUNT(active) FROM users WHERE active = 1";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}

		public function getNumDesactivatedUsers()
		{
			$sql = "SELECT COUNT(active) FROM users WHERE active = 0";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}

		public function getNumAdiminUsers()
		{
			$sql = "SELECT COUNT(id_rol) FROM users WHERE id_rol = 1";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}


		public function getNumClientsUsers()
		{
			$sql = "SELECT COUNT(id_rol) FROM users WHERE id_rol = 2";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}

		public function getNumBusinessUsers()
		{
			$sql = "SELECT COUNT(id_rol) FROM users WHERE id_rol = 3";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}

		/*=====  End of Reportes sobre usuarios  ======*/

		/*===============================================
		=            Reportes sobre empresas            =
		===============================================*/
		public function getNumEnterprises()
		{
			$sql = "SELECT COUNT(*) FROM enterprises";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}

		public function getNumActivatedEnterprises()
		{
			$sql = "SELECT COUNT(active) FROM enterprises WHERE active = 1";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}

		public function getNumDesactivatedEnterprises()
		{
			$sql = "SELECT COUNT(active) FROM enterprises WHERE active = 0";
			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$quantity = $stmt->fetch();

			return $quantity[0];
		}

		/*=====  End of Reportes sobre empresas  ======*/
		
	}
?>