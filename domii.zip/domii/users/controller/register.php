<?php

	require_once("../model/users.php");

	if ($_POST)
	{
		$email = $_POST['userEmail'];
		$password = $_POST['userPassword'];
		$profile = $_POST['userProfile'];

		$User = new User;

		if (!$User->searchRepeated($email))
		{
			if($User->register($email, $password))
			{
				header("location: ../../home/home.php");
			}

			else
			{
				header("location: ../../../../index.php");
			}
		}

		else
		{
			header("location: ../../../../index.php");
		}
	}
?>