<?php

	include('../../public/plugins/google_auth/config.php');
	require_once("../model/users.php");
	$user = new User;

	if (isset($_GET["code"])) {

		$token = $google_client->fetchAccessTokenWithAuthCode($_GET["code"]);
		if (!isset($token['error'])) {

			$google_client->setAccessToken($token['access_token']);

			$_SESSION['access_token'] = $token['access_token'];

			$google_service = new Google_Service_Oauth2($google_client);

			$data = $google_service->userinfo->get();

			if (!empty($data['id'])) {
				$_SESSION['user_id_google'] = $data['id'];
			}

			if (!empty($data['given_name'])) {
				$_SESSION['user_first_name'] = $data['given_name'];
			}

			if (!empty($data['family_name'])) {
				$_SESSION['user_last_name'] = $data['family_name'];
			}

			if (!empty($data['email'])) {
				$_SESSION['user_email_address'] = $data['email'];
			}

			if (!empty($data['picture'])) {
				$_SESSION['user_image'] = $data['picture'];
			}
		}
	}

	if($user->searchExisting($_SESSION['user_email_address']) == false)
	{
		$userName = $_SESSION['user_first_name'] . " " . $_SESSION['user_last_name'];
		if($user->register($userName, $_SESSION['user_email_address'], $_SESSION['user_id_google']))
		{
			if($user->login($_SESSION['user_email_address'], $_SESSION['user_id_google']))
			{
				header("location: ../../home/index.php");
			}
		}
	}

	else
	{
		if($user->login($_SESSION['user_email_address'], $_SESSION['user_id_google']))
		{
			header("location: ../../home/");
		}
	}
?>