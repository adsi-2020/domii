<?php

	require_once("C:/xampp/htdocs/domii/app/Connection.php");

	class User extends Connection
	{
		public function __construct()
		{
			$this->db = parent::__construct();
		}

		public function searchExisting($email)
		{
			$sql = "SELECT * FROM users WHERE email_user = :email";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":email", $email);
			$stmt->execute();

			return ($stmt->rowCount() > 0) ? true : false;
		}

		public function register($name, $email, $id_google)
		{
			$sql = "INSERT INTO
					users (
					name_user,
					email_user,
					id_google_user
					) VALUES (
						:name,
						:email,
						:id_google
					)";

			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":name", $name);
			$stmt->bindParam(":email", $email);
			$stmt->bindParam(":id_google", $id_google);

			return ($stmt->execute()) ? true : false;
		}

		public function login($email, $id_google)
		{
			$sql = "SELECT * FROM users WHERE email_user = :email AND id_google_user = :id_google";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":email", $email);
			$stmt->bindParam(":id_google", $id_google);
			$stmt->execute();

			if($stmt->rowCount() == 1)
			{
				$userData = $stmt->fetch();

				$_SESSION['id_user'] 	= $userData['id_user'];
				$_SESSION['name_user']  = $userData['name_user'];
				$_SESSION['email_user'] = $userData['email_user'];
				$_SESSION['state_user'] = $userData['active'];
				$_SESSION['id_rol'] 	= $userData['id_rol'];
				return true;
			}

			return false;
		}

		public function getId()
		{
			return $_SESSION['id_user'];
		}

		public function getName()
		{
			return $_SESSION['name_user'];
		}

		public function email()
		{
			return $_SESSION['email_user'];
		}

		public function getImg()
		{
			return $_SESSION['user_image'];
		}

		public function isActive()
		{
			return ($_SESSION['state_user'] == 1)  ? true : false;
		}

		public function isLoged()
		{
			return isset($_SESSION['id_user']) ? true : false;
		}

		public function getRol()
		{
			$sql = "SELECT
					name_rol
					FROM roles
					WHERE id_rol = {$_SESSION['id_rol']}";

			$stmt = $this->db->prepare($sql);
			$stmt->execute();
			$data = $stmt->fetch();
			return implode(array_unique($data));
		}

		public function validateSession()
		{
			if (!$this->isLoged())
			{
				include "C:/xampp/htdocs/domii/public/plugins/google_auth/config.php";
				header("location: {$google_client->createAuthUrl()}");
			}

			elseif ($this->isLoged() && $this->getRol() == "ADMINISTRADOR")
			{
				header("location: /domii/administrators/views/index.php");
			}

			elseif ($this->isLoged() && !$this->isActive())
			{
				header("location: /domii/public/plugins/google_auth/logout.php");
			}
		}

		public function validateSessionAsAdministrator()
		{
			if (!$this->isLoged())
			{
				include "C:/xampp/htdocs/domii/public/plugins/google_auth/config.php";
				header("location: {$google_client->createAuthUrl()}");
			}
		}

		public function isOwner($id_user, $id_enterprise)
		{
			$rol = $this->getRol();
			$sql = "SELECT id_enterprise FROM users WHERE id_user = :id_user";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_user", $id_user);
			$stmt->execute();
			$id = $stmt->fetch();

			return ($rol == "EMPRESARIO" && $id[0] == $id_enterprise) ? true : false;
		}

		public function changeRol($id_user, $id_rol)
		{
			$sql = "UPDATE users SET id_rol = :id_rol WHERE id_user = :id_user";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_user", $id_user);
			$stmt->bindParam(":id_rol", $id_rol); 
			return ($stmt->execute()) ? true : false;
		}

		public function setEnterprise($id_enterprise, $id_user)
		{
			$sql = "UPDATE users SET id_enterprise = :id_enterprise WHERE id_user = :id_user";
			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_enterprise", $id_enterprise);
			$stmt->bindParam(":id_user", $id_user);

			return ($stmt->execute()) ? true : false;
		}
	}
?>