<?php
	require_once("C:/xampp/htdocs/domii/app/Connection.php");

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
 

	class Order extends Connection
	{
		public function __construct()
		{
			$this->db = parent::__construct();
		}

		public function add($id_user, $id_product, $quantity_product, $price_product, $total_order, $phone_order, $address_order, $id_enterprise)
		{
			$sql = "INSERT INTO orders (
							id_user,
							id_product,
							quantity_product,
							price_product,
							total_order,
							phone_order,
							address_order,
							id_enterprise
							) VALUES (
								:id_user,
								:id_product,
								:quantity_product,
								:price_product,
								:total_order,
								:phone_order,
								:address_order,
								:id_enterprise
							)";

			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_user", $id_user);
			$stmt->bindParam(":id_product", $id_product);
			$stmt->bindParam(":quantity_product", $quantity_product);
			$stmt->bindParam(":price_product", $price_product);
			$stmt->bindParam(":total_order", $total_order);
			$stmt->bindParam(":phone_order", $phone_order);
			$stmt->bindParam(":address_order", $address_order);
			$stmt->bindParam(":id_enterprise", $id_enterprise);
			return ($stmt->execute()) ? true : false;
		}

		public function getInfo($id_user)
		{
			$sql = "SELECT
			users.name_user,
            enterprises.email_enterprise,
            products.name_product,
            products.description_product,
            orders.price_product,
            orders.quantity_product,
            orders.total_order,
            orders.phone_order,
            orders.address_order,
            orders.id_order,
            orders.date_order
            FROM orders
            INNER JOIN products
            ON products.id_product = orders.id_product
            INNER JOIN users
            ON users.id_user = orders.id_user
            INNER JOIN enterprises
            ON enterprises.id_enterprise = orders.id_enterprise
            WHERE users.id_user = :id_user AND orders.date_order = (SELECT MAX(orders.date_order) FROM orders)";

			$stmt = $this->db->prepare($sql);
			$stmt->bindParam(":id_user", $id_user);
			$stmt->execute();

			$orderData = $stmt->fetch();

			return (isset($orderData)) ? $orderData : null;
		}

		public function sendOrderToEnterprise($orderData) //$orderData es un array con la informacion de la orden
		{

			require '../../public/plugins/phpmiler/vendor/autoload.php';
			$mail = new PHPMailer(true);
			$targetEmail = $orderData['email_enterprise'];

			try {
					$mail = new PHPMailer(true);

					$mail->isSMTP();
					$mail->Host = 'smtp.gmail.com';
					$mail->SMTPAuth = false;
					$mail->SMTPAutoTLS = false;
					$mail->Port = 25;


					// $mail->isSMTP();
					// $mail->CharSet = "UTF-8";
					// $mail->SMTPAuth = true;
					// $mail->SMTPSecure = 'tls';

					$mail->Host = 'smtp.gmail.com';
					$mail->Port = 587;
					$mail->SMTPOptions = array(
						'ssl' => array(
							'verify_peer' => false,
							'verify_peer_name' => false,
							'allow_self_signed' => true
						)
					);

					$mail->isHTML(true);

					$mail->Username = 'proyectosena46@gmail.com';
					$mail->Password = 'datafastadsi2020';

					$mail->setFrom('proyectosena46@gmail.com', 'domii');
					$mail->Subject = '¡Tienes un nuevo pedido!';
					$mail->Body = "
					Alguien está solicitando uno de tus productos. Aquí te dejamos los datos necesarios para que se lo envíes:
					<head>
					<meta charset='UTF-8'>
					<meta name='viewport' content='width=device-width, initial-scale=1.0'>
					<link href='https://fonts.googleapis.com/css2?family=Rubik:wght@300;400&display=swap' rel='stylesheet'>
					<link href='https://file.myfontastic.com/r4oWHDSZCTNCgS8F9u2KKJ/icons.css' rel='stylesheet'>
					<style>
						table {
							background-color: #fff;
							border-collapse: collapse;
							box-shadow: 0px 0px 10px -3px #000;
							text-align: left;
							margin: 1.5em auto;
							font-family: 'Rubik', sans-serif;
						}

						caption {
							padding: .5em;
							box-shadow: 0px 0px 10px -3px #000;
							background-color: #0077ea;
							color: #fff;
							font-size: 1.5em;
						}

						th, td {
							color: #444;
							border: 1px solid #bbb;
							padding: .5em;
							font-size: 1.25em;
						}

						tr:last-child {
							font-size: 1.30em;
						}

						[class^='icon-']{
							position: relative;
							top: .1em;
							margin-right: 0.25em;
						}

					</style>

				</head>
				<body>
					<table class='table-order'>
						<caption>Detalles del pedido</caption>
						<tbody>
							<tr>
								<th>
									<i class='icon-person'></i>
									Cliente
								</th>
								<td>
									{$orderData['name_user']}
								</td>
							</tr>
							<tr>
								<th>
									<i class='icon-phone'></i>
									Teléfono
								</th>
								<td>
									{$orderData['phone_order']}
								</td>
							</tr>
							<tr>
								<th>
									<i class='icon-location'></i>
									Dirección
								</th>
								<td>
									{$orderData['address_order']}
								</td>
							</tr>
							<tr>
								<th>
									<i class='icon-calendar'></i>
									Fecha
								</th>
								<td>
									{$orderData['date_order']}
								</td>
							</tr>
							<tr>
								<th>
									<i class='icon-star'></i>
									Producto
								</th>
								<td>
									{$orderData['name_product']}
								</td>
							</tr>
							<tr>
								<th>
									<i class='icon-file-text'></i>
									Descripción
								</th>
								<td>
									{$orderData['description_product']}
								</td>
							</tr>
							<tr>
								<th>
									<i class='icon-signal'></i>
									Cantidad
								</th>
								<td>
									{$orderData['quantity_product']}
								</td>
							</tr>
							<tr>
								<th>
									<i class='icon-price-tag'></i>Precio 
									unitario
								</th>
								<td>
									$ {$orderData['price_product']}
								</td>
							</tr>
							<tr>
								<th>
									<i class='icon-pricetag-multiple'></i>
									Total
								</th>
								<td>
									$ {$orderData['total_order']}
								</td>
							</tr>
						</tbody>
					</table>
				</body>";

					$mail->addAddress($targetEmail);

					$mail->send();
					return true;

			} catch (Exception $e) {

				echo "El mensaje no fue enviado. Error: {$mail->ErrorInfo}";
				return false;
			}
		}
	}

?>