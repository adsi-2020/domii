<?php
	require_once("../model/orders.php");
	$order = new Order;

	if ($_POST)
	{
		$id_user	  	  = $_POST['id_user'];
		$id_product	  	  = $_POST['id_product'];
		$quantity_product = $_POST['quantity_product'];
		$price_product	  = $_POST['price_product'];
		$total_order	  = $quantity_product * $price_product;
		$phone_order	  = $_POST['phone_order'];
		$address_order	  = $_POST['address_order'];
		$id_enterprise	  = $_POST['id_enterprise'];

		if ($order->add($id_user, $id_product, $quantity_product, $price_product, $total_order, $phone_order, $address_order, $id_enterprise))
		{
			$orderData = $order->getInfo($id_user);
			if($order->sendOrderToEnterprise($orderData))
			{
				header("location: ../../empresas/views/ordersent.php?id={$id_enterprise}"); 

			}
		}
	}

	else
	{
		header("location: ../../home/index.php");
	}
?>