<?php

	class Connection 
	{
		protected $db;
		private $drive = "mysql";
		private $host = "localhost";
		private $dbname = "domii";
		private $user = "root";
		private $password = "";

		public function __construct() 
		{
			try{
				$db = new PDO("{$this->drive}:host={$this->host}; dbname={$this->dbname}", $this->user, $this->password);
				$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				// echo "¡Conectado! <hr>";
				return $db; 
			} catch (PDOException $e) {
				echo "Ha surgido algún error <hr>";
				echo "Detalle: " . $e->getMessage();
			}
		}
	}
?>