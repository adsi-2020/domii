<?php
	include('public/plugins/google_auth/config.php');
	require_once("users/model/users.php");
	$user = new User();
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Recibe tus pedidos en tiempo real por correo electrónico de manera segura y ofrécele comodidad a tus clientes al publicar tus productos en domii. Pide a domicilio en la empresa que más te guste con un par de clicks."/>
	<title>domii</title>
	<link rel="icon" href="public/img/favicon.png">
	<link rel="stylesheet" href="public/css/styles.css">
</head>
<body>
	<?php include_once("templates/main-header.php"); ?>
	<section class="section-copies">
		<div class="group">
			<div class="box">
				<div class="copy__item">
					<h3 class="copy__title">Registra tu empresa</h3>
					<i class="copy__img icon-enterprise"></i>
					<p class="copy__description">Sabemos lo difícil que son estos tiempos de pandemia para tu empresa. Pero tranquilo, por eso llegó domii, para que juntos podamos expandirnos y poder llegar hacia distintos lugares, así tu empresa crece con un solo click ¡SOMOS DOMII!</p>
				</div>
			</div>
			<div class="box">
				<div class="copy__item">
					<h3 class="copy__title">Pide tu domicilio</h3>
					<i class="copy__img icon-moto"></i>
					<p class="copy__description">Con domii evitas habladurías por otras plataformas y ese tiempo lo puedes dedicar en prestar un mejor servicio para que tus clientes sean más felices a la hora de pedir sus productos y así ser más eficaces</p>
				</div>
			</div>
			<div class="box">
				<div class="copy__item">
					<h3 class="copy__title">En menor tiempo</h3>
					<i class="copy__img icon-clock"></i>
					<p class="copy__description">domii se preocupa por ti y por el tiempo de tus pedidos, por eso tratamos de brindarte un servicio de calidad a la hora de llevar tus productos hacia la puerta de tu casa para que junto a los tuyos disfrutes de aquellas cosas que más te gustan. ¡Eso es DOMII!</p>
				</div>
			</div>
			<div class="box">
				<div class="copy__item">
					<h3 class="copy__title">Tu dinero vale</h3>
					<i class="copy__img icon-ticket"></i>
					<p class="copy__description">En domii respetamos tu dinero, por eso si no te gusta nuestro servicio te lo reembolsamos y te recompensamos con un nuevo servicio totalmente gratis, porque tu felicidad no te la quita nadie</p>
				</div>
			</div>
		</div>
	</section>
	<div class="group">
		<div class="box">
			<form class="login--form">
				<a href="<?php echo $google_client->createAuthUrl(); ?>" class="btn-login-google">
					<img src="public/img/google_icon.svg" alt="Icono de Google">
					Continuar con Google
				</a>
			</form>
		</div>
	</div>
	<?php include "templates/footer.php" ?>
	<script src="public/js/main.js"></script>
</body>
</html>